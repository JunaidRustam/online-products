-- insert_categories.sql

INSERT INTO categories (name, priority) VALUES ('Fruits', 1);
INSERT INTO categories (name, priority) VALUES ('Vegetables', 2);